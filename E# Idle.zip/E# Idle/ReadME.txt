(C) all rights Reserved by Phoenix Entertainment, Ascenzo Equizi, Sebastion Cramond and Mark Seneca

Warning: windows may see that the E# idle is a Trojan by Phoenix Entertaiment can ashore you that it is harmless and does not do any damage to your computer.

have fun with the E# Idle and there is an Example.E# file that you can use as a gide in order to learn E#

GO A HEAD AND CODE :)